import { Component, OnInit } from '@angular/core';
import { GeneroService } from '../../../services/genero.service';
import { Genero } from '../../../models/genero';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-genero',
  standalone: true,
  imports: [ CommonModule, FormsModule, RouterModule],
  templateUrl: './genero.component.html',
  styleUrl: './genero.component.css'
})
export class GeneroComponent implements OnInit {
  generos: Genero[] = [];
  nuevoGenero: Genero = { id: 0, nombre: '' };

  constructor(private generoService: GeneroService) {}

  ngOnInit(): void {
    this.obtenerGeneros();
  }

  obtenerGeneros(): void {
    this.generoService.getGeneros().subscribe(generos => this.generos = generos);
  }

  agregarGenero(): void {
    if (this.nuevoGenero.nombre) {
      this.generoService.addGenero(this.nuevoGenero).subscribe(genero => {
        this.generos.push(genero);
        this.nuevoGenero = { id: 0, nombre: '' };
      });
    }
  }

  eliminarGenero(id: number): void {
    this.generoService.deleteGenero(id).subscribe(() => {
      this.generos = this.generos.filter(g => g.id !== id);
    });
  }
}
