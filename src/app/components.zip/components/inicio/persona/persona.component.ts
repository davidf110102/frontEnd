import { Component, OnInit } from '@angular/core';
import { PersonaService } from '../../../services/persona.service';
import { GeneroService } from '../../../services/genero.service';
import { Persona } from '../../../models/persona';
import { Genero } from '../../../models/genero';import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
;

@Component({
  selector: 'app-persona',
  standalone: true,
  imports: [ CommonModule, FormsModule, RouterModule ],
  templateUrl: './persona.component.html',
  styleUrl: './persona.component.css'
})
export class PersonaComponent implements OnInit {
  personas: Persona[] = [];
  generos: Genero[] = [];
  nuevaPersona: Persona = { id: 0, nombre: '', apellido: '', generoId: 0, genero: { id: 0, nombre: '' } };

  constructor(private personaService: PersonaService, private generoService: GeneroService) {}

  ngOnInit(): void {
    this.obtenerPersonas();
    this.obtenerGeneros();
  }

  obtenerPersonas(): void {
    this.personaService.getPersonas().subscribe(personas => this.personas = personas);
  }

  obtenerGeneros(): void {
    this.generoService.getGeneros().subscribe(generos => this.generos = generos);
  }

  agregarPersona(): void {
    if (this.nuevaPersona.nombre && this.nuevaPersona.apellido && this.nuevaPersona.generoId) {
      this.personaService.addPersona(this.nuevaPersona).subscribe(persona => {
        this.personas.push(persona);
        this.nuevaPersona = { id: 0, nombre: '', apellido: '', generoId: 0, genero: { id: 0, nombre: '' } };
      });
    }
  }

  eliminarPersona(id: number): void {
    this.personaService.deletePersona(id).subscribe(() => {
      this.personas = this.personas.filter(p => p.id !== id);
    });
  }

}
